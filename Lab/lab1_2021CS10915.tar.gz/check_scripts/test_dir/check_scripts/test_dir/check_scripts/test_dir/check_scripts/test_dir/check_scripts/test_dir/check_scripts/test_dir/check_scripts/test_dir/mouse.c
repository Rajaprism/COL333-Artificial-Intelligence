#include "types.h"
#include "defs.h"
#include "x86.h"
#include "mouse.h"
#include "traps.h"

// Wait until the mouse controller is ready for us to send a packet
void 
mousewait_send(void) 
{
    while ((inb(0x64) & 0x02) != 0) {

    }
    return;
}

// Wait until the mouse controller has data for us to receive
void 
mousewait_recv(void) 
{
    while ((inb(0x64) & 0x01) == 0) {

    }
    return;
}

// Send a one-byte command to the mouse controller, and wait for it
// to be properly acknowledged
void 
mousecmd(uchar cmd) 
{
    mousewait_send(); 

    outb(0x64, 0xD4); 
    mousewait_send(); 

    outb(0x60, cmd); 
    mousewait_recv(); 

    uchar ack = inb(0x60); 
    if (ack != 0xFA) {
        cprintf("Mouse command acknowledgment error: %x\n", ack);
    }
    return;
}

void
mouseinit(void)
{
    mousewait_send();

    outb(0x64, 0xA8);

    
    mousewait_send();  
    outb(0x64, 0x20);  
    mousewait_recv();  

    uchar status = inb(0x60);
    status |= 0x02;  
    mousewait_send();  
    outb(0x64, 0x60);  
    mousewait_send();  
    outb(0x60, status);  

    mousecmd(0xF6);  
    mousecmd(0xF4);  
    ioapicenable(IRQ_MOUSE, 0);
    cprintf("Mouse has been initialized\n");    // Do not modify this line
    return;
}

void
mouseintr(void)
{
    uchar status;
    uchar data;

    mousewait_recv();  
    int x = 0;

    while ((status = inb(0x64)) & 0x01) {
        //mousewait_recv();
        data = inb(0x60);  

        if (x % 3 == 0){
            if (data & 0x01) {
                cprintf("LEFT\n");
            } else if (data & 0x02) {
                cprintf("RIGHT\n");
            } else if (data & 0x04) {
                cprintf("MID\n");
            }
        }
        x++;
    }
    return;
}