#!/bin/bash
g++ -o p1_read part1.cpp
g++ -o p1_write part1_write.cpp
g++ -o p2 part2.cpp