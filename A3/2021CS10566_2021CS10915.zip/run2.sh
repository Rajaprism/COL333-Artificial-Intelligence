#!/bin/bash
./p1_write $1