#!/bin/bash
./p2 $1