#!/bin/bash
./p1_read $1