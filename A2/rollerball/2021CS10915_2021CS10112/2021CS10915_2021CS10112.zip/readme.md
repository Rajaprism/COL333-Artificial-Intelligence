*COL333 Assignment 2*</br>

1)Teammates names </br>
Raja Kumar 2021CS10915 </br>
Shubham 2021CS10112 </br>

2)Discussion with </br>
Suryanshu Verma 2021CS10962</br>
Shivam Kumar 2021CS10917</br>